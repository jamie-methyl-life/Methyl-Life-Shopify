

    (function( jQuery ){
  // var $module = jQuery('#m-1627381116718').children('.module');
  // You can add custom Javascript code right here.
})( window.GemQuery || jQuery );