

    
    
    
jQuery(function() {
  var $module = jQuery('#m-1607368618721').children('.module');
});
    
    jQuery(function() {var $module = jQuery('#m-1607368618721-child1').children('.module');}); jQuery(function() {var $module = jQuery('#m-1607368618721-child1-0').children('.module');}); jQuery(function() { var $module = jQuery('#m-1607368618721-child1-1').children('.module');}); jQuery(function() {var $module = jQuery('#m-1607368618721-child1-2').children('.module');}); jQuery(function() {var $module = jQuery('#m-1607368618721-child2').children('.module');}); jQuery(function() {var $module = jQuery('#m-1607368618721-child2-0').children('.module');}); jQuery(function() { var $module = jQuery('#m-1607368618721-child2-1').children('.module');}); jQuery(function() {var $module = jQuery('#m-1607368618721-child2-2').children('.module');}); jQuery(function() {var $module = jQuery('#m-1607368618721-child3').children('.module');}); jQuery(function() {var $module = jQuery('#m-1607368618721-child3-0').children('.module');}); jQuery(function() { var $module = jQuery('#m-1607368618721-child3-1').children('.module');}); jQuery(function() {var $module = jQuery('#m-1607368618721-child3-2').children('.module');}); 
    