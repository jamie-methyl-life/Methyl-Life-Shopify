 document.addEventListener('DOMContentLoaded', function () {
    const audio = document.getElementById('audio');
    const playPauseBtn = document.getElementById('play-pause');
    const progressBar = document.getElementById('progress-bar');
    const currentTimeEl = document.getElementById('current-time');
    const durationEl = document.getElementById('duration');
    const volumeIcon = document.getElementById('volume-icon');

    if (audio) {
        // Play/Pause Functionality
        playPauseBtn.addEventListener('click', () => {
            if (audio.paused) {
                audio.play();
                playPauseBtn.innerHTML = '&#10074;&#10074;'; // Pause icon
            } else {
                audio.pause();
                playPauseBtn.innerHTML = '&#9658;'; // Play icon
            }
        });

        // Update Progress Bar and Time
        audio.addEventListener('timeupdate', () => {
            const currentTime = audio.currentTime;
            const duration = audio.duration;
            progressBar.value = (currentTime / duration) * 100;
            
            currentTimeEl.textContent = formatTime(currentTime);
            durationEl.textContent = formatTime(duration);
        });

        // Seek Audio Position
        progressBar.addEventListener('input', () => {
            const duration = audio.duration;
            audio.currentTime = (progressBar.value / 100) * duration;
        });

        // Volume Control
        volumeIcon.addEventListener('click', () => {
            audio.muted = !audio.muted;
            volumeIcon.textContent = audio.muted ? '&#128263;' : '&#128266;';
        });

        // Format Time Helper Function
        function formatTime(time) {
            const minutes = Math.floor(time / 60);
            const seconds = Math.floor(time % 60).toString().padStart(2, '0');
            return `${minutes}:${seconds}`;
        }

        // Load Audio Metadata
        audio.addEventListener('loadedmetadata', () => {
            durationEl.textContent = formatTime(audio.duration);
        });
    }

   const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        item.addEventListener('click', () => {
            item.classList.toggle('opened');
            item.classList.toggle('closed');
        });
    });

   
  const tocList = document.querySelector('#table-of-contents .toc-list');
  if (!tocList) return;

  let currentOl = tocList;
  let headingStack = [];

  // Helper function to create a TOC entry and manage nested lists
  function createTocEntry(heading, currentOl, level) {
    // Exclude specific headings
  const excludedHeadings = ["Product Recommendations", "Related Articles"];
  if (excludedHeadings.includes(heading.textContent.trim())) {
    return currentOl; // Skip creating a TOC entry for these headings
  }
    
    // Create a unique ID if the heading doesn't have one
    if (!heading.id) {
      heading.id = heading.textContent.trim().toLowerCase().replace(/\s+/g, '-');
    }

    // Create a list item for the heading
    const listItem = document.createElement('li');
    listItem.innerHTML = `<a href="#${heading.id}">${heading.textContent}</a>`;

    // Adjust the nested list based on the heading level
    while (headingStack.length && headingStack[headingStack.length - 1] >= level) {
      headingStack.pop();
      currentOl = currentOl.parentElement.closest('ol') || tocList;
    }

    // Create a new <ol> if necessary and assign the appropriate class
    if (level > (headingStack[headingStack.length - 1] || 0)) {
      const newOl = document.createElement('ol');

      // Add a class based on the level to apply custom list styles
      if (level === 2) {
        newOl.classList.add('toc-level-2'); // Alphabetical list style
      } else if (level === 3) {
        newOl.classList.add('toc-level-3'); // Roman numeral list style
      }

      listItem.appendChild(newOl);
      currentOl.appendChild(listItem);
      currentOl = newOl;
    } else {
      currentOl.appendChild(listItem);
    }

    headingStack.push(level);
    return currentOl;
  }

  // Step 1: Process <section> elements with an order attribute
  const sections = Array.from(document.querySelectorAll('section[style*="order"]'));
  sections.sort((a, b) => parseInt(a.style.order || 0) - parseInt(b.style.order || 0));

  sections.forEach((section) => {
    const headings = section.querySelectorAll('h2, h3');
    headings.forEach((heading) => {
      const level = parseInt(heading.tagName.charAt(1));
      currentOl = createTocEntry(heading, currentOl, level);
    });
  });

  // Step 2: Process headings within the .CustomBlogTemplate-FooterContent element
  const footerContent = document.querySelector('.CustomBlogTemplate-FooterContent');
  if (footerContent) {
    const footerHeadings = footerContent.querySelectorAll('h2, h3');
    footerHeadings.forEach((heading) => {
      const level = parseInt(heading.tagName.charAt(1));
      currentOl = createTocEntry(heading, currentOl, level);
    });
  }

   
   // Clone the template content and append it to the form
  const formElement = document.getElementById('add-to-cart');
  if (formElement) {
    const form = formElement.querySelector('form');
    const template = formElement.querySelector('template');
    if (form && template) {
      form.append(template.content.cloneNode(true));
    }
  }
  const formElementSide = document.getElementById('add-to-cart-top');
  if (formElementSide) {
    const formSide = formElementSide.querySelector('form-side');
    const templateSide = formElementSide.querySelector('template');
    if (formSide && templateSide) {
      formSide.append(templateSide.content.cloneNode(true));
    }
  }
  // Function to handle the "Add to Cart" button click
  function handleAddToCartClick() {
    // Add classes to the body element
    document.body.classList.add('sidebar-opened', 'sidebar-opened--right');

    // Add the class to the sidebar drawer element
    const sidebarDrawer = document.querySelector('sidebar-drawer#site-cart-sidebar');
    if (sidebarDrawer) {
      sidebarDrawer.style.display = 'grid';
      setTimeout(function(){
        sidebarDrawer.classList.add('sidebar--opened')
      },1300);
      
    }
  }

  // Event listener for the "Add to Cart" button
  document.addEventListener('click', function(event) {
    // Check if the clicked element is the "Add to Cart" button
    if (event.target && event.target.closest('.add-to-cart-button')) {
      handleAddToCartClick();
    }
  });

    const accordionHeader = document.querySelector('.accordion-header');
    const accordionContent = document.querySelector('.accordion-content');
    const accordionIcon = document.querySelector('.accordion-icon');
    
    if (accordionHeader && accordionContent) {
        accordionHeader.addEventListener('click', function () {
            if (window.innerWidth <= 767) {
                accordionContent.classList.toggle('open');
                accordionHeader.classList.toggle('open');
            }
        });
    }

});